// Navbar
const nav = document.querySelector("#navBar");
const mobileNav = document.querySelector("#mobileNav");
window.addEventListener('scroll', (e) => {
    if (window.scrollY >= 560) {
        nav.classList.add("show");
    } else {
        nav.classList.remove("show");
    }
})
window.addEventListener('scroll', (e) => {
    if (window.scrollY >= 260) {
        mobileNav.classList.add("show");
    } else {
        mobileNav.classList.remove("show");
    }
})

window.addEventListener("load", function() {
    const preload = document.querySelector(".preload");
    const timeline = gsap.timeline();
    // preload.classList.add("preload-finish");    
    timeline.to(preload, {
        opacity: 0,
        ease: "power1",
        duration: .2,
        delay: .8,
        pointerEvents: "none"
    });
})

let tl = gsap.timeline();


tl.to(".preload", {
        backgroundColor: "#121212",
        ease: "power2.in",
        duration: .6
    })
    .to("#emo", {
        duration: 1,
        opacity: 1,
        scale: 1.3,
    })
    .to("#emo", {
        duration: 1.6,
        filter: 'drop-shadow(2px 4px 6px #e5222b)',
        ease: "back",
        repeat: -1,
        yoyo: true,
    });